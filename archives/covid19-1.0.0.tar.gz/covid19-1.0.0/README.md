# Covi19-Cli


## Installation
- Install pip or conda
- `git clone https://github.com/asprazz/covid19-cli.git`
- `cd covid19-cli`
- confirm that you have `requests` and `argparse` already installed in your environment
- run `install.sh` script for package installation, requires `pip3`
- You can run cli app using command `covid19`
